pathways-app
============

Pathways app for MedSavant.

##Install instructions

This app is available in the MedSavant app store.

If you would like to use the MedSavant Pathways plugin available in this repository, you need to have the MedSavant Client and Server already installed and functional. See http://genomesavant.com/p/medsavant/ for details.

Once you have the Client and Server ready, download MedSavant-App - Pathways-1.0.0.jar from the dist folder of this repository, and put in in your ~/.medsavant/plugins/ directory.

The next time you log into the MedSavant Client, the icon for Pathway Analysis should be displayed. Clicking on that icon will allow you to use the Pathways plugin.

###Google Summer of Code Submission

If your lib folder is empty, you will have to fill it with the following files:
* axis-1.4.jar
* org.bridgedb.bio.jar
* commons-discovery-0.5.jar
* org.bridgedb.jar
* cytoscape.jar
* org.pathvisio.core.jar
* impl-3.1.0-sources.jar
* org.wikipathways.client.jar
* jaxrpc-10.3.jar
* slf4j-api-1.7.7.jar
* jsc.jar
* wsdl4j-1.6.2.jar

If your medsavant/pathways/wikipathwaysPNG folder is empty, you will have to fill it with all the PNG files downloadable from the [Wikipathways website](http://www.wikipathways.org//wpi/batchDownload.php?species=Homo%20sapiens&fileType=png&tag=Curation:AnalysisCollection before using the MedSavant Pathways plugin.)

##Usage instructions

A tutorial for the pathways plugin can be found [here](getting_started_guide.pdf).

##Build instructions

To build the project from source, you must have NetBeans installed. Download the source code, and go into the NetBeans menu to File > Open Project, and then navigate to the downloaded code. Select the project in the Project panel, and select Run > Clean and Build.

##Future Directions

Features that would be nice to have in the future include:
* Ability to print out a comprehensive PDF report of results
* [GREAT annotation](http://bejerano.stanford.edu/papers/GREAT.pdf) for intergenic variants
* BiNGO test for Gene Ontology term enrichment
* incorporate functional impact scores into enrichment tests
